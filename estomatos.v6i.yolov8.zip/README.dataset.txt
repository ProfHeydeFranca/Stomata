# estômatos > 2025-05-13 12:25pm
https://universe.roboflow.com/worktown/estomatos

Provided by a Roboflow user
License: CC BY 4.0

